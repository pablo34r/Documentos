export const portalPositions = [{ x: 1860, y: 825 }];
