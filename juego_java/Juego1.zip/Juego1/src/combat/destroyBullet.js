export function destroyBullet(bullet, platform) {
  bullet.destroy();
}
